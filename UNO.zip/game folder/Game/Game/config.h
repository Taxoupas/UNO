#pragma once


#define ASSET_PATH "assets\\" // path for assets folder

#define WINDOW_WIDTH 1200 // WINDOW
#define WINDOW_HEIGHT 600

#define CANVAS_WIDTH 1000 // CANVAS
#define CANVAS_HEIGHT 500
